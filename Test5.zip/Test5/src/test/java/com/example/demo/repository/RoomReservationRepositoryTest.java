package com.example.demo.repository;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.RoomReservation;

@SpringBootTest
public class RoomReservationRepositoryTest {
	
	@Autowired
	RoomReservationRepository roomReservationRepository;
	
	@Test
	public void roomresrvation등록() {
		List<RoomReservation> roomList = new ArrayList<>();
		
		LocalDate localDate1 = LocalDate.of(2024, 6, 1);
		LocalDate localDate2 = LocalDate.of(2024, 6, 2);
		LocalDate localDate3 = LocalDate.of(2024, 6, 2);
		
		
		RoomReservation room1 = new RoomReservation(0, 201, "둘리", localDate1);
		RoomReservation room2 = new RoomReservation(0, 201, "둘리", localDate2);
		RoomReservation room3 = new RoomReservation(0, 202, "또치", localDate3);
		
		roomList.add(room1);
		roomList.add(room2);
		roomList.add(room3);
		
		roomReservationRepository.saveAll(roomList);
		
	}
	
	@Test
	public void roomresrvation조회() {
		List<RoomReservation> roomList = roomReservationRepository.findAll();
		for(RoomReservation room :roomList ) {
			System.out.println(room);
		}
	}

}
