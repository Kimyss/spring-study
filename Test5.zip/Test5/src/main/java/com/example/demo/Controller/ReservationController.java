package com.example.demo.Controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.RoomReservation;


@Controller
@RequestMapping("/reservation")
public class ReservationController {

	@GetMapping("/list")
	public void q2(Model model) {

		List<RoomReservation> list = new ArrayList<>();
		
		LocalDate localDate1 = LocalDate.of(2024, 6, 1);
		LocalDate localDate2 = LocalDate.of(2024, 6, 2);
		LocalDate localDate3 = LocalDate.of(2024, 6, 2);
		
		list.add(new RoomReservation(1, 201, "둘리", localDate1));
		list.add(new RoomReservation(2, 201, "둘리", localDate2));
		list.add(new RoomReservation(3, 202, "또치", localDate3));
		
		model.addAttribute("list",list);
		
//		RoomReservationRepository roomReservationRepository;
//		List<RoomReservation> 
	}
	
	@GetMapping("/save")
	public void q3(Model model) {
		
	}
	
	@PostMapping("/save")
	public void q3q3(Model model) {
		
	}

}
